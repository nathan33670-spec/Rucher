import axios from 'axios'
import { useAuthStore } from '../stores/auth'

const api = axios.create({ baseURL: '/api' })

let _authStore = null

api.interceptors.request.use((config) => {
  // Fallback sur localStorage si le store Pinia n'est pas encore prêt
  try {
    if (!_authStore) _authStore = useAuthStore()
    if (_authStore.token) {
      config.headers.Authorization = `Bearer ${_authStore.token}`
    }
  } catch {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
  }
  return config
})

api.interceptors.response.use(
  (r) => r,
  (error) => {
    if (error.response?.status === 401) {
      try {
        if (!_authStore) _authStore = useAuthStore()
        _authStore.logout()
      } catch {
        localStorage.removeItem('token')
        localStorage.removeItem('user')
      }
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
