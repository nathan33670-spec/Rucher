import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vuetify from 'vite-plugin-vuetify'

export default defineConfig({
  plugins: [vue(), vuetify({ autoImport: true })],
  appType: 'spa',
  optimizeDeps: {
    include: [
      'vue', 'vue-router', 'pinia', 'axios',
      'vuetify',
    ],
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: ['ruches.corsicajack.fr'],
    proxy: {
      '^/api/': 'http://backend:8000',
      '/ws': { target: 'http://backend:8000', ws: true },
    },
  },
})
