"""Routes — Inventaire."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.inventory import InventoryItem, InventoryMovement, MovementType
from app.models.user import User, RoleEnum
from app.schemas.inventory import ItemCreate, ItemUpdate, ItemOut, MovementCreate, MovementOut
from app.utils.auth import get_current_user, require_roles
from app.utils.audit import log_action

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


@router.get("/", response_model=list[ItemOut])
async def list_items(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    result = await db.execute(select(InventoryItem).order_by(InventoryItem.name))
    return result.scalars().all()


@router.post("/", response_model=ItemOut, status_code=201)
async def create_item(
    body: ItemCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(RoleEnum.ADMIN, RoleEnum.YARD_MANAGER, RoleEnum.TREASURER)),
):
    item = InventoryItem(**body.model_dump())
    db.add(item)
    await db.flush()
    await log_action(db, user.id, "create", "inventory_item", item.id)
    return item


@router.put("/{item_id}", response_model=ItemOut)
async def update_item(
    item_id: int, body: ItemUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(RoleEnum.ADMIN, RoleEnum.YARD_MANAGER, RoleEnum.TREASURER)),
):
    item = await db.get(InventoryItem, item_id)
    if not item:
        raise HTTPException(404, "Article introuvable")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(item, k, v)
    await log_action(db, user.id, "update", "inventory_item", item.id)
    return item


@router.delete("/{item_id}", status_code=204)
async def delete_item(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(RoleEnum.ADMIN)),
):
    item = await db.get(InventoryItem, item_id)
    if not item:
        raise HTTPException(404, "Article introuvable")
    await db.delete(item)
    await log_action(db, user.id, "delete", "inventory_item", item_id)


@router.post("/movements", response_model=MovementOut, status_code=201)
async def create_movement(
    body: MovementCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(RoleEnum.ADMIN, RoleEnum.YARD_MANAGER, RoleEnum.TREASURER)),
):
    item = await db.get(InventoryItem, body.item_id)
    if not item:
        raise HTTPException(404, "Article introuvable")

    if body.movement_type == MovementType.IN:
        item.quantity += body.quantity
    else:
        if item.quantity < body.quantity:
            raise HTTPException(400, "Stock insuffisant")
        item.quantity -= body.quantity

    mvt = InventoryMovement(
        item_id=body.item_id,
        movement_type=body.movement_type,
        quantity=body.quantity,
        reason=body.reason,
        hive_id=body.hive_id,
        transaction_id=body.transaction_id,
        performed_by=user.id,
    )
    db.add(mvt)
    await db.flush()
    await log_action(db, user.id, "create", "inventory_movement", mvt.id)
    return mvt


@router.get("/movements", response_model=list[MovementOut])
async def list_movements(
    item_id: int = None,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    q = select(InventoryMovement).order_by(InventoryMovement.performed_at.desc()).limit(100)
    if item_id:
        q = q.where(InventoryMovement.item_id == item_id)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/alerts")
async def stock_alerts(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    """Retourne les articles dont le stock est sous le seuil d'alerte."""
    result = await db.execute(
        select(InventoryItem).where(
            InventoryItem.alert_threshold.isnot(None),
            InventoryItem.quantity <= InventoryItem.alert_threshold,
        )
    )
    items = result.scalars().all()
    return [{"id": i.id, "name": i.name, "quantity": i.quantity, "threshold": i.alert_threshold} for i in items]


@router.put("/{item_id}/move")
async def move_item(
    item_id: int,
    new_location: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(RoleEnum.ADMIN, RoleEnum.YARD_MANAGER)),
):
    """Déplace un article vers un nouveau point de stockage."""
    item = await db.get(InventoryItem, item_id)
    if not item:
        raise HTTPException(404, "Article introuvable")
    old_location = item.location
    item.location = new_location or None
    await log_action(db, user.id, "move", "inventory_item", item.id,
                     details=f"{old_location} → {new_location}")
    return {"id": item.id, "name": item.name, "location": item.location}


@router.get("/locations/summary")
async def locations_summary(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Résumé par point de stockage : nombre d'articles, quantité totale, valeur."""
    result = await db.execute(
        select(
            func.coalesce(InventoryItem.location, 'Non assigné').label('location'),
            func.count(InventoryItem.id).label('item_count'),
            func.sum(InventoryItem.quantity).label('total_qty'),
            func.sum(InventoryItem.quantity * InventoryItem.unit_price).label('total_value'),
        ).group_by(InventoryItem.location).order_by('location')
    )
    return [
        {"location": r.location, "item_count": r.item_count,
         "total_qty": r.total_qty or 0, "total_value": float(r.total_value or 0)}
        for r in result.all()
    ]
