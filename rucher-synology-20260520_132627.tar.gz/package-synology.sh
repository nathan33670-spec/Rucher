#!/usr/bin/env bash
# Archive le projet pour déploiement Synology
# - Copie les sources essentielles (backend/frontend/nginx, compose, scripts)
# - Exclut les données et les dossiers lourds (pg_data, upload_data, node_modules, .git...)
# Usage: ./package-synology.sh [output-archive-path]

set -eu

OUT=${1:-"rucher-synology-$(date +%Y%m%d_%H%M%S).tar.gz"}

TMPDIR=$(mktemp -d)
echo "Création d'une copie propre du projet dans $TMPDIR ..."

# Fichiers / dossiers à inclure
INCLUDES=(
  backend
  frontend
  nginx
  docker-compose.prod.yml
  deploy-synology.sh
  package-synology.sh
  run-local.sh
  .env.example
  README.md
  docs
)

# Exclure les éléments lourds / temporaires
EXCLUDES=(
  --exclude='.git'
  --exclude='.git/*'
  --exclude='**/node_modules'
  --exclude='**/.venv'
  --exclude='logs'
  --exclude='*.log'
  --exclude='__pycache__'
  --exclude='*.pyc'
  --exclude='rucher-synology-*.tar.gz'
  --exclude='pg_data'
  --exclude='upload_data'
  --exclude='frontend/dist'
)

pushd "$TMPDIR" >/dev/null

echo "Copying selected files..."
for p in backend frontend nginx docker-compose.prod.yml deploy-synology.sh package-synology.sh run-local.sh .env.example README.md; do
  if [ -e "$OLDPWD/$p" ]; then
    cp -R "$OLDPWD/$p" .
  fi
done

popd >/dev/null

echo "Création de l'archive $OUT (exclusions appliquées)..."
# Place exclude options before the file list so tar treats them as options (BSD tar on macOS
# can interpret them as file names if they come after the file list)
tar czf "$OUT" "${EXCLUDES[@]}" -C "$TMPDIR" .

echo "Calcul du checksum..."
if command -v shasum >/dev/null 2>&1; then
  shasum -a 256 "$OUT" > "$OUT.sha256"
else
  sha256sum "$OUT" > "$OUT.sha256" || true
fi

echo "Nettoyage temporaire..."
rm -rf "$TMPDIR"

echo ""
echo "✅ Archive créée : $OUT"
echo "✅ Checksum : ${OUT}.sha256"
echo "Transférez cette archive sur votre Synology et exécutez le script deploy-synology.sh depuis l'archive extraite."

